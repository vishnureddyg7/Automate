from fastapi import FastAPI, File, UploadFile, HTTPException
from app.preprocess import partition_document
from app.summarize import summarize_text_or_table, summarize_images
from app.vectorstore import initialize_vectorstore, add_to_vectorstore
import os
import shutil

# Initialize FastAPI
app = FastAPI()

# Ensure the content directory exists
CONTENT_FOLDER = "./content/"
os.makedirs(CONTENT_FOLDER, exist_ok=True)

# Initialize the vectorstore and retriever
vectorstore, retriever = initialize_vectorstore()

@app.post("/upload/")
async def upload_document(file: UploadFile = File(...)):
    """
    API endpoint to upload a document for processing.
    """
    file_path = os.path.join(CONTENT_FOLDER, file.filename)
    try:
        # Save the file to the content folder
        with open(file_path, "wb") as f:
            shutil.copyfileobj(file.file, f)
        
        # Process the uploaded document
        chunks = partition_document(file_path)

        # Separate elements into text, tables, and images
        texts = [chunk for chunk in chunks if "CompositeElement" in str(type(chunk))]
        tables = [chunk for chunk in chunks if "Table" in str(type(chunk))]
        images = [chunk.metadata.orig_elements for chunk in chunks if "Image" in str(type(chunk))]

        # Summarize the elements
        text_summaries = summarize_text_or_table(texts)
        table_summaries = summarize_text_or_table([table.metadata.text_as_html for table in tables])
        image_summaries = summarize_images(images)

        # Add the summaries to the vectorstore
        add_to_vectorstore(vectorstore, retriever, texts, tables, images, text_summaries, table_summaries, image_summaries)

        return {"message": f"Document '{file.filename}' uploaded and processed successfully."}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing file: {str(e)}")


@app.get("/retrieve/")
async def retrieve_data(query: str):
    """
    API endpoint to retrieve data from the vectorstore based on a query.
    """
    try:
        docs = retriever.invoke(query)
        results = [doc.page_content for doc in docs]
        return {"query": query, "results": results}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error retrieving data: {str(e)}")